package com.pack.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.exception.EmployeeNotFoundException;
import com.pack.model.Employee;
import com.pack.service.EmployeeService;

@Controller
public class EmployeeController {
	
	final static Logger logger = LogManager.getLogger(EmployeeController.class);

	@Autowired
    EmployeeService employeeService;

	@RequestMapping("/add")
	public String toAdd(Model model) {
		    
		  logger.info("into add");
		model.addAttribute("empBean",new Employee());
	 		return  "emp";
		}
	
	
	

	

	@RequestMapping("/save")
	public String saveEmp(@ModelAttribute("empBean") Employee employee)
	{ 
		  logger.info("into save");
	 
	//  logger.error("Saving emp object"+employee);
		employeeService.saveEmployee(employee);
		return "redirect:/viewForm";
	}
	
	
	
	
	@RequestMapping("/save1")
	public String saveEmp1(@ModelAttribute("empBean") Employee employee)
	{ 
		  logger.info("into save1");
	 
	//  logger.error("Saving emp object"+employee);
		employeeService.saveEmployee(employee);
		return "redirect:/viewForm1";
	}
	
	@RequestMapping("/save2")
	public String saveEmp2(@ModelAttribute("empBean") Employee employee)
	{ 
		  logger.info("into save1");
	 
	//  logger.error("Saving emp object"+employee);
		employeeService.saveEmployee(employee);
		return "redirect:/viewForm2";
	}
	
	
	  @RequestMapping(value="/index1", method = RequestMethod.GET)
	  public String  index1() {
	  
	  return "index1"; 
	  }
	  
	  @RequestMapping(value="/index", method = RequestMethod.GET)
	  public String  index() {
	  
	  return "index"; 
	  }
	  
	 

	
	
	
	  @RequestMapping(value="/getId", method = RequestMethod.GET)
	  public String  getId() {
	  
	  return "getIdForm"; 
	  }
	  
	  
	  @RequestMapping(value="/getIdMod", method = RequestMethod.GET) 
	  public String   getIdMod()
	  {
		  logger.info("into getIdMod");
	  return "getIdModForm";
	  
	  }
	  
	  @RequestMapping(value="/getIdMod1", method = RequestMethod.GET) 
	  public String   getIdMod1()
	  {
		  logger.info("into getIdMod");
	  return "getIdModForm1";
	  
	  }
	  
	  @RequestMapping(value="/getIdMod2", method = RequestMethod.GET) 
	  public String   getIdMod2()
	  {
		  logger.info("into getIdMod");
	  return "getIdModForm2";
	  
	  }
	  
	  
	  
	  
	  
	  @RequestMapping(value="/del", method = RequestMethod.POST)
	  public String  delete(@RequestParam("id") int id,Employee employee,Model m) 
	  {
	  
	  String page=null;
	  try { 
		  if (employeeService.getEmployeeById(id).isPresent())
	          { 
			  employee=employeeService.getEmployeeById(id).get();
	          employeeService.deleteEmployee(employee);
	          page="pageSuccess";
	      } else 
	           throw new EmployeeNotFoundException();
	  
	           
		  } catch(EmployeeNotFoundException e)
	  
	  { 
			  m.addAttribute("exception",e);
	          page="ExceptionPage";
	  
	  }
	  
	  return page;
	 
	 
}


@RequestMapping(value="/update", method = RequestMethod.POST)  
public String update(@RequestParam("id") int  id,Model m)
{
	Employee employee=null;
	String page=null;
	try
			{
	 if (employeeService.getEmployeeById(id).isPresent())
	 {
		  employee=employeeService.getEmployeeById(id).get();
		  m.addAttribute("updateBean", employee);
		  page="showUpdateForm";
		 
	 }
	 else 
	  throw new EmployeeNotFoundException();
	   
		  
		}
		  catch(EmployeeNotFoundException e)
		  {
			  m.addAttribute("exception",e);
		    	page="ExceptionPage";
			 
		  }

     return page;
	
}
@RequestMapping(value="/update1", method = RequestMethod.POST)  
public String update1(@RequestParam("id") int  id,Model m)
{
	Employee employee=null;
	String page=null;
	try
			{
	 if (employeeService.getEmployeeById(id).isPresent())
	 {
		  employee=employeeService.getEmployeeById(id).get();
		  m.addAttribute("updateBean", employee);
		  page="showUpdateForm1";
		 
	 }
	 else 
	  throw new EmployeeNotFoundException();
	   
		  
		}
		  catch(EmployeeNotFoundException e)
		  {
			  m.addAttribute("exception",e);
		    	page="ExceptionPage";
			 
		  }

     return page;
	
}

@RequestMapping(value="/update2", method = RequestMethod.POST)  
public String update2(@RequestParam("id") int  id,Model m)
{
	Employee employee=null;
	String page=null;
	try
			{
	 if (employeeService.getEmployeeById(id).isPresent())
	 {
		  employee=employeeService.getEmployeeById(id).get();
		  m.addAttribute("updateBean", employee);
		  page="showUpdateForm2";
		 
	 }
	 else 
	  throw new EmployeeNotFoundException();
	   
		  
		}
		  catch(EmployeeNotFoundException e)
		  {
			  m.addAttribute("exception",e);
		    	page="ExceptionPage";
			 
		  }

     return page;
	
}








  @RequestMapping("/viewForm") 
  public String viewemp(Model m){
	  List<Employee>   list=employeeService.viewAll(); 
	  m.addAttribute("list",list); 
	  return "view";
	  }
  @RequestMapping("/viewForm1") 
  public String viewemp1(Model m){
	  List<Employee>   list=employeeService.viewAll(); 
	  m.addAttribute("list",list); 
	  return "view";
	  }
  
  @RequestMapping("/viewForm3") 
  public String viewemp3(Model m){
	  List<Employee>   list=employeeService.viewAll(); 
	  m.addAttribute("list",list); 
	  return "view2";
	  }
  
  
  @RequestMapping("/viewForm2") 
  public String viewemp2(Model m){
	  List<Employee>   list=employeeService.viewAll(); 
	  m.addAttribute("list",list); 
	  return "view1";
	  }
 
 
  @RequestMapping("/findByStatus") 
  public String findByStatus()
  {
	  
	  return "getStatus";
  }
  
 
  
  @RequestMapping("/getDetails") 
  public String getName(@RequestParam("status")String status,Model m)
  {
	  System.out.println("status "+status);
	  List<Employee> list=employeeService.findByStatus(status);
	  System.out.println("list "+list);
	  m.addAttribute("list", list);
	  return "statusPage";
	  
  }
  
  @RequestMapping("/myQuery") 
  public String myQuery()
  {
	  System.out.println("in my query");
	  return "myQuery";
  }
  
  
  @RequestMapping("/result") 
  public String getName(@RequestParam("ename")String name,@RequestParam("desig")String desig,Model m)
  {
	  System.out.println("desig "+desig);
	  Employee emp=employeeService.getEmployee(name, desig);
	  
	  m.addAttribute("emp", emp);
	  return "resultPage";
	  
  }
 
  
 
	  
  
}

 
