package com.pack.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@Controller
public class HomeController {

	 

		@GetMapping("/admin")
		public String admin() {
			return "index1";
		}

		@GetMapping("/user")
		public String user() {
			return "index";
		}

		@GetMapping("/all")
		public String all() {
			return "allPage";
		}
	}